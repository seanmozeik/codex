//! Expression evaluation and content-origin propagation.
use super::State;
use super::calls;
use crate::Transform;
use crate::children;
use crate::text;
use crate::value::Value;
use std::collections::BTreeMap;
use tree_sitter::Node;

impl State<'_> {
    pub(super) fn eval_member(&mut self, node: Node<'_>, depth: usize) -> Value {
        let object = node.child_by_field_name("object");
        let property = node
            .child_by_field_name("attribute")
            .or_else(|| node.child_by_field_name("property"));
        match (object, property) {
            (Some(o), Some(p)) => {
                let base = self.eval(o, depth + 1);
                let name = text(p, self.source).to_owned();
                match base {
                    Value::Api(api) => Value::Api(format!("{api}.{name}")),
                    Value::Object(fields) if self.language == crate::Language::TypeScript => {
                        fields.get(&name).cloned().unwrap_or(Value::Data)
                    }
                    Value::Data if self.language == crate::Language::TypeScript => Value::Data,
                    other => Value::Member(Box::new(other), name),
                }
            }
            _ => Value::Unknown,
        }
    }
    pub(super) fn eval_call(&mut self, node: Node<'_>, depth: usize) -> Value {
        let function = node
            .child_by_field_name("function")
            .map_or(Value::Unknown, |n| self.eval(n, depth + 1));
        if let Some(arguments) = node.child_by_field_name("arguments")
            && arguments.kind() == "generator_expression"
        {
            let value = self.eval_comprehension(arguments, depth + 1);
            return calls::evaluate(self, node, function, &[value], &BTreeMap::new());
        }
        let arg_nodes = node
            .child_by_field_name("arguments")
            .map(children)
            .unwrap_or_default();
        let mut args = vec![];
        let mut keywords = BTreeMap::new();
        for arg in arg_nodes {
            if arg.kind() == "keyword_argument" {
                if let (Some(name), Some(value)) = (
                    arg.child_by_field_name("name"),
                    arg.child_by_field_name("value"),
                ) {
                    keywords.insert(
                        text(name, self.source).to_owned(),
                        self.eval(value, depth + 1),
                    );
                }
            } else {
                args.push(self.eval(arg, depth + 1));
            }
        }
        calls::evaluate(self, node, function, &args, &keywords)
    }
    pub(super) fn eval_object(&mut self, node: Node<'_>, depth: usize) -> Value {
        let mut map = BTreeMap::new();
        let mut complete = true;
        for pair in children(node) {
            if let (Some(k), Some(v)) = (
                pair.child_by_field_name("key"),
                pair.child_by_field_name("value"),
            ) {
                let key = if k.kind() == "property_identifier" {
                    Some(text(k, self.source).to_owned())
                } else {
                    self.eval(k, depth + 1).text()
                };
                let value = self.eval(v, depth + 1);
                if let Some(key) = key {
                    map.insert(key, value);
                } else {
                    self.gap(k, "Computed object key is unresolved");
                    complete = false;
                }
            } else {
                self.gap(pair, "Computed object property is unresolved");
                complete = false;
            }
        }
        if complete {
            Value::Object(map)
        } else {
            Value::Unknown
        }
    }
    pub(super) fn eval_binary(&mut self, node: Node<'_>, depth: usize) -> Value {
        let Some(left) = node.child_by_field_name("left") else {
            return Value::Unknown;
        };
        let Some(right) = node.child_by_field_name("right") else {
            return Value::Unknown;
        };
        let a = self.eval(left, depth + 1);
        let b = self.eval(right, depth + 1);
        let operator = self.source[left.end_byte()..right.start_byte()].trim();
        match (a, b, operator) {
            (Value::Path(a), Value::Text(b), "/") => Value::Path(if b.starts_with('/') {
                b
            } else {
                format!("{}/{b}", a.trim_end_matches('/'))
            }),
            (Value::Text(a), Value::Text(b), "+") => Value::Text(format!("{a}{b}")),
            (
                Value::Content {
                    target,
                    mut transforms,
                },
                Value::Text(_),
                "+",
            )
            | (
                Value::Text(_),
                Value::Content {
                    target,
                    mut transforms,
                },
                "+",
            ) => {
                if transforms.len() < 32 {
                    transforms.push(Transform::TextConcatenation);
                }
                Value::Content { target, transforms }
            }
            (
                Value::Content {
                    target: a,
                    mut transforms,
                },
                Value::Content { target: b, .. },
                "+",
            ) if a == b => {
                if transforms.len() < 32 {
                    transforms.push(Transform::TextConcatenation);
                }
                Value::Content {
                    target: a,
                    transforms,
                }
            }
            _ => Value::Unknown,
        }
    }
    pub(super) fn eval_subscript(&mut self, node: Node<'_>, depth: usize) -> Value {
        let receiver = node
            .child_by_field_name("value")
            .or_else(|| node.child_by_field_name("object"));
        let index = node
            .child_by_field_name("subscript")
            .or_else(|| node.child_by_field_name("index"));
        let value = receiver.map_or(Value::Unknown, |n| self.eval(n, depth + 1));
        if index.is_some_and(|n| n.kind() == "slice") {
            if let Some(index) = index {
                for bound in children(index) {
                    self.eval(bound, depth + 1);
                }
            }
            if let Value::Content {
                target,
                mut transforms,
            } = value
            {
                if transforms.len() < 32 {
                    transforms.push(Transform::TextSlice);
                }
                return Value::Content { target, transforms };
            }
            Value::Data
        } else {
            let key = index.map_or(Value::Unknown, |n| self.eval(n, depth + 1));
            match (value, key) {
                (Value::Object(fields), Value::Text(key)) => {
                    fields.get(&key).cloned().unwrap_or(Value::Data)
                }
                (Value::Array(values), _) => index
                    .and_then(|n| text(n, self.source).parse::<usize>().ok())
                    .and_then(|i| values.get(i).cloned())
                    .unwrap_or(Value::Data),
                (Value::Data | Value::Text(_) | Value::Content { .. }, _) => Value::Data,
                _ => {
                    self.gap(node, "Subscript is unresolved");
                    Value::Unknown
                }
            }
        }
    }
}
