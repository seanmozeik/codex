//! Recognised standard-library calls and content transformations.
mod options;
mod process;
use super::State;
use super::imports;
use crate::Effect;
use crate::Target;
use crate::Transform;
use crate::WriteMode;
use crate::value::HandleMode;
use crate::value::Value;
use std::collections::BTreeMap;
use tree_sitter::Node;

pub(super) fn evaluate(
    state: &mut State<'_>,
    node: Node<'_>,
    function: Value,
    args: &[Value],
    keywords: &BTreeMap<String, Value>,
) -> Value {
    if let Some(reason) = options::uncertainty(&function, args, keywords) {
        state.gap(node, reason);
    }
    let first = args.first().cloned().unwrap_or(Value::Unknown);
    match function {
        Value::Api(api) => evaluate_api(state, node, &api, first, args, keywords),
        Value::Member(receiver, method) => {
            if let Some(value) = super::data::method(&receiver, &method) {
                return value;
            }
            match (*receiver, method.as_str()) {
                (Value::Path(path), "unlink" | "rmdir") => {
                    state.emit(
                        node,
                        Effect::FileDelete {
                            target: Value::Path(path).target(state.cwd.as_deref()),
                        },
                    );
                    Value::Unknown
                }
                (Value::Handle { target, .. }, "truncate") => {
                    state.emit(node, Effect::FileTruncate { target });
                    Value::Unknown
                }
                (Value::Handle { .. }, "close") => Value::Unknown,
                (Value::Path(path), "read_text" | "read_bytes") => {
                    read(state, node, Value::Path(path).target(state.cwd.as_deref()))
                }
                (Value::Path(path), "write_text" | "write_bytes") => {
                    write(
                        state,
                        node,
                        Value::Path(path).target(state.cwd.as_deref()),
                        args.first(),
                        WriteMode::Replace,
                    );
                    Value::Unknown
                }
                (Value::Path(path), "open") => open(
                    state,
                    node,
                    &Value::Path(path),
                    args.first().or_else(|| keywords.get("mode")),
                ),
                (Value::Path(path), "glob" | "rglob" | "iterdir") => {
                    state.emit(
                        node,
                        Effect::FileList {
                            target: Value::Path(path).target(state.cwd.as_deref()),
                        },
                    );
                    Value::Unknown
                }
                (
                    Value::Handle {
                        target,
                        mode: HandleMode::Read,
                    },
                    "read" | "readlines" | "text" | "json",
                ) => read(state, node, target),
                (
                    Value::Handle {
                        target,
                        mode: HandleMode::Write(mode),
                    },
                    "write",
                ) => {
                    write(state, node, target, args.first(), mode);
                    Value::Unknown
                }
                _ => {
                    state.gap(node, "Receiver or method cannot be resolved");
                    Value::Unknown
                }
            }
        }
        _ => {
            state.gap(node, "Unknown callable; bindings invalidated");
            state.bindings.clear();
            Value::Unknown
        }
    }
}

fn read(state: &mut State<'_>, node: Node<'_>, target: Target) -> Value {
    state.emit(
        node,
        Effect::FileRead {
            target: target.clone(),
        },
    );
    Value::Content {
        target,
        transforms: vec![],
    }
}
fn write(
    state: &mut State<'_>,
    node: Node<'_>,
    target: Target,
    content: Option<&Value>,
    mode: WriteMode,
) {
    if matches!(mode, WriteMode::Replace)
        && let Some(Value::Content {
            target: origin,
            transforms,
        }) = content
        && *origin == target
        && !matches!(target, Target::Unresolved)
        && !transforms.is_empty()
    {
        state.emit(
            node,
            Effect::FileEdit {
                target,
                transforms: transforms.clone(),
            },
        );
        return;
    }
    state.emit(node, Effect::FileWrite { target, mode });
}
fn open(state: &mut State<'_>, node: Node<'_>, path: &Value, mode: Option<&Value>) -> Value {
    let target = path.target(state.cwd.as_deref());
    let mode = match mode {
        None => HandleMode::Read,
        Some(Value::Text(s)) => match s.as_str() {
            "r" | "rb" | "rt" => HandleMode::Read,
            "w" | "wb" | "wt" => HandleMode::Write(WriteMode::Replace),
            "a" | "ab" | "at" => HandleMode::Write(WriteMode::Append),
            "x" | "xb" | "xt" => HandleMode::Write(WriteMode::ExclusiveCreate),
            _ => HandleMode::Unknown,
        },
        _ => HandleMode::Unknown,
    };
    if let HandleMode::Write(write_mode) = &mode {
        state.emit(
            node,
            Effect::FileOpen {
                target: target.clone(),
                mode: *write_mode,
            },
        );
    } else if matches!(mode, HandleMode::Unknown) {
        state.emit(
            node,
            Effect::FileOpen {
                target: target.clone(),
                mode: WriteMode::Unknown,
            },
        );
        state.gap(
            node,
            "File open mode is unresolved; it may mutate the target",
        );
    }
    Value::Handle { target, mode }
}
fn transform(value: Value, method: Transform) -> Value {
    match value {
        Value::Content {
            target,
            mut transforms,
        } => {
            if transforms.len() < 32 {
                transforms.push(method);
            }
            Value::Content { target, transforms }
        }
        _ => Value::Unknown,
    }
}

fn evaluate_api(
    state: &mut State<'_>,
    node: Node<'_>,
    api: &str,
    first: Value,
    args: &[Value],
    keywords: &BTreeMap<String, Value>,
) -> Value {
    if let Some(value) = super::data::call(api, args) {
        return value;
    }
    if let Some(value) = super::data::json_io(state, node, api, args) {
        return value;
    }
    if let Some(effect) = options::explicit_effect(api, first.target(state.cwd.as_deref())) {
        state.emit(node, effect);
        return Value::Unknown;
    }
    match api {
        "open" => open(
            state,
            node,
            &first,
            args.get(1).or_else(|| keywords.get("mode")),
        ),
        "str" => match first {
            Value::Path(s) => Value::Text(s),
            v => v,
        },
        "print" | "text" | "console.log" | "console.error" => Value::Unknown,
        "require" | "import" => imports::load(state, node, &first),
        "fs.readFile" | "fs.readFileSync" | "Deno.readTextFile" | "Deno.readTextFileSync" => {
            if api.starts_with("fs.")
                && let Some(Value::Object(fields)) = args.get(1)
                && fields
                    .get("flag")
                    .is_some_and(|value| !matches!(value, Value::Text(flag) if flag == "r"))
            {
                state.emit(
                    node,
                    Effect::FileOpen {
                        target: first.target(state.cwd.as_deref()),
                        mode: options::write_mode(api, args.get(1)),
                    },
                );
            }
            read(state, node, first.target(state.cwd.as_deref()))
        }
        "fs.writeFile"
        | "fs.writeFileSync"
        | "fs.appendFile"
        | "fs.appendFileSync"
        | "Bun.write"
        | "Deno.writeTextFile"
        | "Deno.writeTextFileSync" => {
            let mode = options::write_mode(api, args.get(2));
            write(
                state,
                node,
                first.target(state.cwd.as_deref()),
                args.get(1),
                mode,
            );
            Value::Unknown
        }
        "fs.readdir" | "fs.readdirSync" | "os.listdir" | "os.walk" => {
            state.emit(
                node,
                Effect::FileList {
                    target: first.target(state.cwd.as_deref()),
                },
            );
            Value::Unknown
        }
        "Bun.file" => Value::Handle {
            target: first.target(state.cwd.as_deref()),
            mode: HandleMode::Read,
        },
        "re.sub" => transform(
            args.get(2).cloned().unwrap_or(Value::Unknown),
            Transform::RegexSubstitution,
        ),
        "subprocess.run"
        | "subprocess.call"
        | "subprocess.check_output"
        | "subprocess.check_call"
        | "subprocess.Popen"
        | "child_process.exec"
        | "child_process.execSync"
        | "child_process.spawn"
        | "child_process.spawnSync"
        | "child_process.execFile"
        | "child_process.execFileSync" => {
            process::evaluate(state, node, api, &first, args, keywords);
            Value::Unknown
        }
        "tools.exec_command" => {
            process::tool_command(state, node, first);
            Value::Unknown
        }
        _ => {
            state.gap(node, "Unsupported API call; effects are unknown");
            Value::Unknown
        }
    }
}
