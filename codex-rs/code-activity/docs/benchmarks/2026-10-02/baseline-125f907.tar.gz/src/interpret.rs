use crate::Basis;
use crate::Effect;
use crate::Language;
use crate::MAX_NESTING;
use crate::MAX_OPERATIONS;
use crate::Operation;
use crate::OperationId;
use crate::Report;
use crate::SourceId;
use crate::Span;
use crate::Unresolved;
use crate::children;
use crate::span;
use crate::text;
use crate::value::Value;
use crate::value::string_literal;
use std::collections::HashMap;
use tree_sitter::Node;

mod calls;
mod control;
mod data;
mod expressions;
mod imports;
mod statements;

pub struct Embedded {
    pub source: String,
    pub language: Language,
    pub cwd: Option<String>,
    pub parent: Span,
}
pub struct State<'a> {
    source: &'a str,
    source_id: SourceId,
    language: Language,
    cwd: Option<String>,
    bindings: HashMap<String, Value>,
    report: &'a mut Report,
    embedded: Vec<Embedded>,
    visited: usize,
}

pub fn analyze(
    root: Node<'_>,
    source: &str,
    source_id: SourceId,
    language: Language,
    cwd: Option<String>,
    report: &mut Report,
) -> Vec<Embedded> {
    let globals: &[&str] = match language {
        Language::Python => &[
            "open", "print", "str", "len", "int", "float", "abs", "round", "sum", "sorted", "list",
            "bool", "min", "max", "any", "all",
        ],
        Language::TypeScript => &[
            "require", "import", "Bun", "Deno", "JSON", "tools", "text", "console",
        ],
        Language::Shell => &[],
    };
    let mut state = State {
        source,
        source_id,
        language,
        cwd,
        bindings: globals
            .iter()
            .map(|s| (s.to_string(), Value::Api(s.to_string())))
            .collect(),
        report,
        embedded: vec![],
        visited: 0,
    };
    state.eval(root, 0);
    state.embedded
}

impl State<'_> {
    fn gap(&mut self, node: Node<'_>, reason: &str) {
        if self.report.unresolved.len() < MAX_OPERATIONS {
            self.report.unresolved.push(Unresolved {
                evidence: span(node, self.source_id),
                reason: reason.into(),
            });
        }
    }
    fn emit(&mut self, node: Node<'_>, effect: Effect) {
        if self.report.operations.len() >= MAX_OPERATIONS {
            self.gap(node, "Operation budget exceeded");
            return;
        }
        self.report.operations.push(Operation {
            id: OperationId(self.report.operations.len()),
            evidence: span(node, self.source_id),
            basis: Basis::StaticIntent,
            effect,
        });
    }
    fn bind(&mut self, node: Node<'_>, value: Value) {
        if !value.within_budget() || self.bindings.len() >= 256 {
            self.gap(
                node,
                "Abstract value or binding budget exceeded; bindings invalidated",
            );
            self.bindings.clear();
            return;
        }
        if node.kind() == "object_pattern"
            && let Value::Api(api) = value
        {
            for property in children(node) {
                let (name, alias) = if property.kind() == "shorthand_property_identifier_pattern" {
                    (Some(property), Some(property))
                } else {
                    (
                        property.child_by_field_name("key"),
                        property.child_by_field_name("value"),
                    )
                };
                if let (Some(name), Some(alias)) = (name, alias) {
                    self.bind(
                        alias,
                        Value::Api(format!("{api}.{}", text(name, self.source))),
                    );
                } else {
                    self.gap(property, "Unsupported module destructuring");
                }
            }
        } else if matches!(
            node.kind(),
            "identifier" | "shorthand_property_identifier_pattern"
        ) {
            self.bindings
                .insert(text(node, self.source).to_owned(), value);
        } else {
            self.gap(
                node,
                "Assignment target cannot be resolved; bindings invalidated",
            );
            self.bindings.clear();
        }
    }
    fn eval(&mut self, node: Node<'_>, depth: usize) -> Value {
        self.visited += 1;
        if depth > MAX_NESTING || self.visited > 50_000 {
            self.gap(node, "AST traversal budget exceeded");
            return Value::Unknown;
        }
        match node.kind() {
            "module"
            | "program"
            | "block"
            | "statement_block"
            | "lexical_declaration"
            | "variable_declaration"
            | "expression_statement" => {
                let mut value = Value::Unknown;
                for child in children(node) {
                    value = self.eval(child, depth + 1);
                }
                value
            }
            "import_statement" | "import_from_statement" => {
                imports::bind(self, node);
                Value::Unknown
            }
            "assignment" | "assignment_expression" | "variable_declarator" => {
                self.eval_assignment(node, depth)
            }
            "identifier" | "import" => self
                .bindings
                .get(text(node, self.source))
                .cloned()
                .unwrap_or(Value::Unknown),
            "string" => {
                if children(node).iter().any(|n| n.kind() == "interpolation") {
                    self.eval_format(node, depth)
                } else {
                    string_literal(text(node, self.source), self.language)
                        .map_or(Value::Unknown, Value::Text)
                }
            }
            "template_string" => {
                if children(node)
                    .iter()
                    .any(|n| n.kind() == "template_substitution")
                {
                    Value::Unknown
                } else {
                    string_literal(text(node, self.source), Language::TypeScript)
                        .map_or(Value::Unknown, Value::Text)
                }
            }
            "await_expression"
            | "parenthesized_expression"
            | "as_expression"
            | "non_null_expression" => node
                .named_child(0)
                .map_or(Value::Unknown, |n| self.eval(n, depth + 1)),
            "attribute" | "member_expression" => self.eval_member(node, depth),
            "call" | "call_expression" => self.eval_call(node, depth),
            "list" | "tuple" | "array" => Value::Array(
                children(node)
                    .into_iter()
                    .map(|n| self.eval(n, depth + 1))
                    .collect(),
            ),
            "object" | "dictionary" => self.eval_object(node, depth),
            "binary_operator" | "binary_expression" => self.eval_binary(node, depth),
            "subscript" | "subscript_expression" => self.eval_subscript(node, depth),
            "with_statement" => self.eval_with(node, depth),
            "for_statement" | "for_in_statement" => self.eval_loop(node, depth),
            "if_statement" => self.eval_branches(node, depth),
            "list_comprehension" | "generator_expression" => self.eval_comprehension(node, depth),
            "assert_statement" | "comparison_operator" | "boolean_operator" => {
                for part in children(node) {
                    self.eval(part, depth + 1);
                }
                Value::Data
            }
            "integer" | "float" | "number" | "none" | "null" | "regex" => Value::Data,
            "true" => Value::Boolean(true),
            "false" => Value::Boolean(false),
            "comment" | "type_annotation" | "interface_declaration" | "type_alias_declaration" => {
                Value::Unknown
            }
            _ => {
                self.gap(
                    node,
                    "Unsupported syntax or control flow; region skipped and bindings invalidated",
                );
                self.bindings.clear();
                Value::Unknown
            }
        }
    }
}
